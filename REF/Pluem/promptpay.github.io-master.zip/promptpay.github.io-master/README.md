# promptpay.github.io
Generate PromptPay QR Code

## List of data request.
- PromptPay ID (Phone number, ID Card, TAX ID)
- Amount (option)

---

## 100% Of privacy.
This public site not store any your information.

---

# PoC Transfer to Bank
This source code test with
- BAY - Bank of Ayudhya
- BBL - Bangkok Bank
- KBANK - Kasikorn Bank
- KTB - Krung Thai Bank
- SCB - Siam Commercial Bank
- TBANK - Thanachart Bank
---

## References
- Github [davidshimjs/qrcodejs](https://github.com/davidshimjs/qrcodejs)
- Github [dtinth/promptpay-qr](https://github.com/dtinth/promptpay-qr)
- Github [chitchcock/CRC16-CCITT.js](https://gist.github.com/chitchcock/5112270)
- [Blognone](https://www.blognone.com/node/95133)
- [ENVCo](https://www.emvco.com/emv-technologies/qrcodes/)
---

## License
MIT License

---

## Contact
twitter [@MrNonz](https://twitter.com/MrNonz)
